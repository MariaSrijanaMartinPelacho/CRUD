<?php
include("conexion.php");
$con=conectar();

$id=$_GET['id'];

$sql ="SELECT * FROM alumno WHERE id_alumno = '$id'"
$query = mysqli_query($con,$sql);

$row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-betal/dist/css/bootstrap.min.css" rel= "stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
<div class = "container mt - 5">
   <form action = "update.php" method = "POST" >
            <input type = "hidden" name = " id_alumno " value = "<?php echo $row [ 'id_alumno'] ?> " >

            <input type = "text" class= "form - control mb - 3" name = "nombre" placeholder = "nombre" value = " <?php echo $row [ 'nombre' ] ?> " >
            <input type = "text" class = "form - control mb - 3" name = "apellidos" placeholder = "apellidos" value = " <?php echo $row [ 'apellidos' ] ?> " >
            <input type = "text" class = "form - control mb - 3" name = "clase" placeholder = "clase" value = " <?php echo $row [ 'clase' ] ?> " >
            <input type = "text" class = "form - control mb - 3" name = "libro" placeholder = "libro" value = " <?php echo $row [ 'libro' ] ?> " >
            <input type = "text" class = "form - control mb - 3" name = "id_libro" placeholder = "id_libro" value = " <?php echo $row [ 'id_libro' ] ?> " >   
        
            <input type = "submit" class = "btn btn - primary btn - block" value = "Actualizar" >

</body>
</html>
