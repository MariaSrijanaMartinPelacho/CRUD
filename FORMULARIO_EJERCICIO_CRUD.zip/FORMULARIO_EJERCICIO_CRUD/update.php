<?php
include("conexion.php");
$con=conectar();

$id_alumnos=$POST['id_alumno'];
$Nombre=$POST['Nombre'];
$apellidos=$POST['apellidos'];
$clase=$POST['clase'];
$libro=$POST['libro'];
$id_libro=$POST['id_libro'];

$sql ="INSERT INTO alumno VALUES ('$id_alumnos','$Nombre','$apellidos', '$clase', '$libro', '$id_libro')"
$query = mysqli_query($con,$sql);

if ($query){
    Header("LOCALITATION: libros_alumnos.php")
}
?>