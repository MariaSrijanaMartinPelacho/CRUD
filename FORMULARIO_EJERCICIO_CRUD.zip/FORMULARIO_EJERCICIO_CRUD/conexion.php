<?php

/*empezamos conectando con xampp poniendo las caracteristicas de nuestro servidor
se puede encontrar eso en cualquier tabla donde pone privilegios*/
function connectar(){
    $host = "localhost";
    $user = "root";
    $pass = ""; //si usaramos el usbwebserver tendríamos que poner una contraseña

//nombre de la tabla de datos donde guardaremos los datos 
    $bd = "Primer_Crud";

//codigo para que el servidor encuentre todas las bases de datos q hay en el portatil  
    $con = mysqli_connect($host,$user,$pass);
//este codio hara que busque en concreto la base de datos que le emos nombrado anteriormente
    mysqli_select_bd($con,$bd);
//nos retorna la bd que se ha encontrado
    return $con;
}