<?php

//incluimos lo que hay en el apartado de conexión
    include("conexion.php"); 
//llamamos el con q se ha retornado en conexion 
    $con = conectar();
//llamamos la tabla libros_alumnos
    $sql="SELECT * FROM libros_alumnos";
//codigos para ejecutar el query
    $query = mysqli_query($con,$sql);
    $row = mysqli_fetch_array ($query);

?>

//EMPEZAMOS HTML QUE SERÁ EL CUERPO
<<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
    <div class="separacion_margenes">
        <div class= "separación_partes">
            <div class="Parte_1">
                <h1> FORMULARIO </h1>
                <!-- Cuando el alumno inserte todos los datos del formulario y le da al botón -->
                <form action="insertar.php" method="Post">

                <!-- Los campos del formulario -->
                <imput type="text" class="form-Parte_1" name="id_alumno" placeholder="ID Alumno">
                <imput type="text" class="form-Parte_1" name="nombre" placeholder="Nombre">   
                <imput type="text" class="form-Parte_1" name="apellidos" placeholder="Apellidos">   
                <imput type="text" class="form-Parte_1" name="clase" placeholder="Clase">
                <imput type="text" class="form-Parte_1" name="libro" placeholder="Clase"> 
                <imput type="text" class="form-Parte_1" name="id_libro" placeholder="ID Libro"> 

            </div>
            
            <div class="Parte_2">
                <h1> Tabla Registro </h1>
                <table class="table">
                <!-- thead es la cabeza, es la parte superior de la tabla que veremos después de poner los datos -->
                    <thead class="tabla cambios">
                        <tr>

                            <th>ID_alumno</th>
                            <th>Nombre</th>
                            <th>Apellidos</th>
                            <th>Clase</th>
                            <th>Libro</th>
                            <th>Id Libro</th>
                            <th></th>
                            <th></th>
                            
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        //Hacemos un arreglo para que se vayan guardando los datos
                            while($row=mysqli_fetch_array($query)){
                        ?>
                            <tr>  

                                <th><?php echo $row['id_alumno']?></th>
                                <th><?php echo $row['nombre']?></th>
                                <th><?php echo $row['apellidos']?></th>
                                <th><?php echo $row['clase']?></th>
                                <th><?php echo $row['libro']?></th>
                                <th><?php echo $row['id_libro']?></th>
                                <th><a href = "actualizaciones.php?id=<?php echo $row ['id_alumno']?>" class = "btn btn-info">EDITAR></a></th>
                                <th><a href = "delete.php?id=<?php echo $row ['id_alumno']?>" class = "btn btn-danger">ELIMINAR></a></th>

                            
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
<!-- ID_alumno, nombre, apellidos, clase, libro, numero de libro-->